using System.Configuration;
using System.Data;
using System.Windows;

namespace wpfUI
{

    public partial class App : Application
    {
    }

}